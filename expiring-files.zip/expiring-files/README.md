# Expiring Files - File Sharing mit verfallenden Links

Ein Express.js Server für die sichere Dateifreigabe via WhatsApp oder andere Kanäle. Dateien sind nur für 4 Tage über generierte Links erreichbar.

## Features

✅ Token-basierte Ablauf-Links (4 Tage Standard)  
✅ Server-seitige Token-Validierung (sicher!)  
✅ CORS aktiviert für Cross-Origin Requests  
✅ HTML Wrapper-Pattern für elegante UI  
✅ Express.js Backend  
✅ JSON Token-Speicherung (persistent)  

## Schnellstart (Lokal)

### Installation

```bash
npm install
```

### Starten

```bash
npm start
```

Server läuft auf `http://localhost:3000`

### Erste Verwendung

1. **Token generieren:**
```
GET http://localhost:3000/api/generate?days=4
```

Response:
```json
{
  "token": "a1b2c3d4e5f6...",
  "expiresAt": 1699999999000,
  "shareLink": "http://localhost:3000/share/a1b2c3d4e5f6...",
  "message": "Link expires in 4 days"
}
```

2. **Link teilen:**
Kopiere `shareLink` und teile ihn via WhatsApp, Email, etc.

3. **Empfänger öffnet Link:**
- Sieht automatisch die Validierung
- Bei Gültig: Button "Anleitung anzeigen"
- Bei Abgelaufen: "Link ist abgelaufen"

## API Endpoints

### GET /api/generate?days=4
**Generiert einen neuen verfallenden Link**

Query Parameters:
- `days` (optional): Verfallstage (Standard: 4)

Response:
```json
{
  "token": "hex-string",
  "expiresAt": 1234567890000,
  "shareLink": "https://example.com/share/hex-string",
  "message": "Link expires in 4 days"
}
```

### GET /api/check?token=TOKEN
**Prüft ob ein Token noch gültig ist**

Response (gültig):
```json
{
  "valid": true,
  "expiresAt": 1234567890000,
  "daysLeft": 3
}
```

Response (abgelaufen):
```json
{
  "valid": false
}
```

### GET /api/content?token=TOKEN
**Gibt die tatsächliche Datei zurück (nur wenn Token gültig)**

- Status 200: HTML-Inhalt der Datei
- Status 401: Token ungültig/abgelaufen
- Status 404: Datei nicht gefunden

### GET /api/tokens
**Listet alle aktiven Tokens (Admin)**

Response:
```json
[
  {
    "token": "a1b2c3d4...",
    "expiresAt": "2024-11-15T12:00:00Z",
    "daysLeft": 3
  }
]
```

### GET /share/:token
**Zeigt die Wrapper-Seite mit Validierung**

Empfänger öffnet diese URL und sieht:
- Loading-State
- Validierungsstatus (Gültig ✅ oder Abgelaufen ⏰)
- Button zum Anzeigen (wenn gültig)

### GET /health
**Health Check**

Response:
```json
{
  "status": "OK",
  "timestamp": "2024-11-12T10:00:00Z"
}
```

## Dateistruktur

```
expiring-files/
├── server.js                 # Express Backend
├── package.json             # Dependencies
├── revolut-anleitung.html   # Tatsächliche Datei
├── expiring-wrapper.html    # Wrapper mit Validierung
├── tokens.json              # Persistierte Tokens (auto-erstellt)
└── README.md                # Diese Datei
```

## Deployment auf Railway

### Schritt 1: GitHub Repository
1. Geh zu https://github.com/new
2. Repository-Name: `expiring-files`
3. Beschreibung: "File sharing with expiring links"
4. Public
5. Create

### Schritt 2: Dateien hochladen
1. Klick "Add file" → "Upload files"
2. Lade diese 5 Dateien hoch:
   - server.js
   - package.json
   - revolut-anleitung.html
   - expiring-wrapper.html
   - README.md
3. Commit: "Initial commit"

### Schritt 3: Railway Deployment
1. Geh zu https://railway.app
2. Neues Projekt
3. "Deploy from GitHub"
4. Wähle `stan2301999/expiring-files`
5. Railway detectet Node.js und deployed automatisch!

### Schritt 4: Live gehen
Railway gibt dir eine URL (z.B. `https://expiring-files-production.up.railway.app`)

Teste:
```
https://expiring-files-production.up.railway.app/health
```

Generiere Token:
```
https://expiring-files-production.up.railway.app/api/generate?days=4
```

## Environment Variables (Railway)

Nicht erforderlich für Grundfunktion, aber optional:

- `PORT`: Server Port (Standard: 3000)
- `NODE_ENV`: `production` oder `development`

## Sicherheit

⚠️ **Token-Sicherheit:**
- Tokens sind zufällig generiert (16 bytes = 128-bit)
- Server-seitig validiert (nicht manipulierbar vom Client)
- Verfallen automatisch nach X Tagen
- Tokens werden in `tokens.json` gespeichert

⚠️ **Wichtig:**
- `tokens.json` enthält sensitive Daten → nicht in Git-Repo
- Für Produktion: Datenbankback-up überlegen
- HTTPS verwenden (Railway macht das automatisch)

## Troubleshooting

### "Cannot find module 'express'"
```bash
npm install
```

### "revolut-anleitung.html not found"
Stelle sicher, dass `revolut-anleitung.html` im gleichen Verzeichnis wie `server.js` ist.

### Tokens verfallen nicht
Die Datei `tokens.json` wird nie cleanup, aber abgelaufene Tokens werden beim nächsten Request ignoriert. Für Production: Cleanup-Job hinzufügen.

### CORS Fehler
CORS ist bereits aktiviert. Falls trotzdem Probleme: Check `server.js` Zeile mit `app.use(cors())`

## Lizenz

MIT

## Support

Falls Probleme auftreten:
1. Logs checken (`console.log` Output)
2. `/health` Endpoint prüfen
3. Token manuell überprüfen: `/api/tokens`
